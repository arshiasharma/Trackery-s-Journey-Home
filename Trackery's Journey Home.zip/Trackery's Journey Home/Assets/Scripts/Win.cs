﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Win : MonoBehaviour
{
    public Text winText;
    public static bool ifWin = false;

    private void Start()
    {
        winText.enabled = false;
    }

    public void OnCollisionEnter2D(Collision2D col)
    {

        if (col.gameObject.tag == "Player")
        {
            winText.enabled = true;
            winText.text = "YOU WIN!";
            ifWin = true;
            GameOver.isPlayerDead = true;
        }
    }
}
