﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class GameOver : MonoBehaviour
{

	public static bool isPlayerDead = false;
	private Text gameOver;

	void Start()
	{
		gameOver = GetComponent<Text>();
	}

	void Update()
	{
		//if the player loses - show game over text
		if (isPlayerDead)
		{
			Time.timeScale = 0;
            gameOver.enabled = true;
            gameOver.text = "GAME OVER \nPRESS R TO RESTART";
            

			//updates the highest score if you earn a higher score 
			if (PlayerScore.playerScore > PlayerScore.highScore)
			{
				using (StreamWriter sw = new StreamWriter(@"Assets/Scripts/HighScore.txt"))
				{
					sw.WriteLine(PlayerScore.playerScore);
				}
			}
        }
        else
        {
            gameOver.enabled = false;
        }
	}
}
