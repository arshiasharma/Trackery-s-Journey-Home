﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BonusHealth : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D other)
    {

        //if enemy bullet hits the player, game over, player loses
        if (other.gameObject.name == "Player")
        {
            GameObject playerBase = other.gameObject;
            HealthManagement healthManagement = playerBase.GetComponent<HealthManagement>();

            if (healthManagement.health < 6)
            {
                healthManagement.health += 1;
                Destroy(this.gameObject);
            }
            else
            {
                Debug.Log("Full health, no bonus health needed");
            }
        }
    }
}
