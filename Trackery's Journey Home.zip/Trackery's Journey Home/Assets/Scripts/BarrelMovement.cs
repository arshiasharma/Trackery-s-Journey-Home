﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarrelMovement : MonoBehaviour
{
	private float timer;
	private float maxTimer;
	public GameObject enemy;
 
	// Start is called before the first frame update
	void Start()
	{
		maxTimer = Random.Range(5f, 12f);
		timer = 0;
	}

	// Update is called once per frame
	void Update()
	{
		//StartCoroutine("SpawnEnemyTimer");

        if(Camera.main.WorldToViewportPoint(transform.position).y < 0)
        {
            Destroy(this.gameObject);
            PlayerScore.playerScore += 20;
        }
	}

    /*
	void SpawnEnemy()
	{
		float y = 1.25f;

		Vector3 spawnPoint = Camera.main.ViewportToWorldPoint(new Vector3(Random.Range(0, 1f), y, 0));

		spawnPoint.z = 0;

		GameObject.Instantiate(enemy, spawnPoint, new Quaternion(0, 0, 0, 0));
	}

	IEnumerator SpawnEnemyTimer()
	{
		if (timer >= maxTimer)
		{
			SpawnEnemy();
			maxTimer = Random.Range(5f, 12f);
			timer = 0;
		}

		timer += 0.025f;
		yield return new WaitForSeconds(0.07f);
	}
    */

    void OnCollisionEnter2D(Collision2D other)
    {
        //if enemy bullet hits the player, game over, player loses
        if (other.gameObject.name == "Player")
        {
            GameObject playerBase = other.gameObject;
            HealthManagement healthManagement = playerBase.GetComponent<HealthManagement>();
            healthManagement.health -= 2;
            Destroy(this.gameObject);
        }
    }
}

