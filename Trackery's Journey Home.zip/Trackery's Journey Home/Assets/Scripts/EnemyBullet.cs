﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : MonoBehaviour
{
    public Transform bullet;
    public float speed;

    // Use this for initialization - makes the bullet
    void Start()
    {
        bullet = GetComponent<Transform>();
    }

    void FixedUpdate()
    {

        //bullet code fires, find the parent enemy, call get componenent on gamecomponent renderer and check the flip.x value is true or false

        if (EnemyMovement.enemyFlip)
        {
            bullet.position = new Vector2(bullet.position.x + speed, bullet.position.y);
        }
        else
        {
            bullet.position = new Vector2(bullet.position.x + -speed, bullet.position.y);
        }
        

        //if the bullet goes off screen 
        if (bullet.position.x <= -10)
            Destroy(bullet.gameObject);
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        //if enemy bullet hits the player, game over, player loses
        if (other.gameObject.name == "Player")
        {
            GameObject playerBase = other.gameObject;
            HealthManagement healthManagement = playerBase.GetComponent<HealthManagement>();
            healthManagement.health -= 1;
            Destroy(bullet.gameObject);
        }

        else if (other.gameObject.tag == "Bullet")
        {
            Destroy(gameObject);
            Destroy(other.gameObject);
        }
    }
}
