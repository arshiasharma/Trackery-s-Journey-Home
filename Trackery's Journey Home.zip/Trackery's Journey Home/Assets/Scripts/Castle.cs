﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Castle : MonoBehaviour
{
    public GameObject castle;
    // Start is called before the first frame update
    void Start()
    {
        castle.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if(PlayerScore.playerScore >= 300)
        {
            castle.SetActive(true);
        }

        else
        {
            castle.SetActive(false);
        }
    }
}
