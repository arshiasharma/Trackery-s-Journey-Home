﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    public Transform player;
    private Rigidbody2D rb;
    public Transform shooter;
    private Vector2 movement;
    public GameObject shot;
    public float fireRate = 0.997f;
    public static bool enemyFlip;

    public static int enemyHealth;
    SpriteRenderer m_SpriteRenderer;

    // Start is called before the first frame update
    void Start()
    {
        enemyHealth = 5;
        rb = this.GetComponent<Rigidbody2D>();
        shooter = GetComponent<Transform>();
        m_SpriteRenderer = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 direction = player.position - transform.position;
        direction.Normalize();
        movement = direction;

        Debug.Log(movement);

        Vector2 flip  = new Vector2();
        flip[0] = 1.0f;
        flip[1] = movement[1];



        if (movement.x > 0)
        {
            m_SpriteRenderer.flipX = true;
            enemyFlip = true;
        }
        else
        {
            m_SpriteRenderer.flipX = false;
            enemyFlip = false;
        }

    }

    private void FixedUpdate()
    {
        moveCharacter(movement);

        //EnemyBulletController called 
        if (Random.value < fireRate)
        {
            Instantiate(shot, shooter.position, shooter.rotation);
        }
    }

    void moveCharacter(Vector2 direction)
    {
        rb.MovePosition((Vector2)transform.position + (direction * 0.5f * Time.deltaTime));
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        //if enemy bullet hits the player, game over, player loses
        if (other.gameObject.name == "Player")
        {
            GameOver.isPlayerDead = true;
        }
        
    }

}

