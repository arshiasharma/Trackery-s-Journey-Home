﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrow : MonoBehaviour
{
    private Transform bullet;
    public float speed;
    string arrowDirection;
    SpriteRenderer m_SpriteRenderer;

    public AudioSource audioB;

    // Start is called before the first frame update
    void Start()
    {
        audioB = GetComponent<AudioSource>();

        if (Pause.paused == false)
        {
            bullet = GetComponent<Transform>();
            m_SpriteRenderer = GetComponent<SpriteRenderer>();

            if (PlayerMovement.direction == "right")
            {
                bullet.position = new Vector2(bullet.position.x + speed, bullet.position.y);
                arrowDirection = "right";
            }
            else if (PlayerMovement.direction == "left")
            {
                bullet.position = new Vector2(bullet.position.x + -speed, bullet.position.y);
                arrowDirection = "left";
                m_SpriteRenderer.flipX = true;

            }
        }

    }

    void Update()
    {
        if(Pause.paused == false)
        {
            if (arrowDirection == "right")
            {
                bullet.position = new Vector2(bullet.position.x + speed, bullet.position.y);
            }
            else if (arrowDirection == "left")
            {
                bullet.position = new Vector2(bullet.position.x + -speed, bullet.position.y);
            }

            //if bullet goes offscreen
            if (bullet.position.x <= -10)
            {
                //player shoots a bunch of bullets so this handles when it goes off the frame
                Destroy(gameObject);
            }
        }
       
    }

    void OnCollisionEnter2D(Collision2D other)
    {

        //if they hit an object tagged enemy, it'll destroy enemy and the bullet and add points
        if (other.gameObject.tag == "Enemy")
        {
            if(EnemyMovement.enemyHealth == 1)
            {
                Destroy(other.gameObject);
            }
            else
            {
                EnemyMovement.enemyHealth--;
                Destroy(this.gameObject);
            }

            Destroy(this);
            PlayerScore.playerScore += 50;

        }

        else if(other.gameObject.tag == "Bullet")
        {
            Destroy(gameObject);
            Destroy(other.gameObject);
        }

        else if(other.gameObject.tag == "Barrel")
        {

            Destroy(gameObject);
            Destroy(other.gameObject);
            audioB.Play();

            PlayerScore.playerScore += 25;
        }
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if(col.gameObject.tag == "Enemy")
        {

            if (EnemyMovement.enemyHealth == 1)
            {
                Destroy(col.gameObject);
                Destroy(this.gameObject);
            }
            else
            {
                EnemyMovement.enemyHealth--;
                Destroy(this.gameObject);
            }

            Destroy(this);
            PlayerScore.playerScore += 50;
        }
    }
}
