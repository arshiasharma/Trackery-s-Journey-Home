﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class PlayerScore : MonoBehaviour
{
	//displays the player's score 

	public static int playerScore = 0;
	public static int highScore = 0;
	private Text scoreText;
	// Use this for initialization
	void Start()
	{
		scoreText = GetComponent<Text>();

		//Reading into the file to know what the high score is
		using (StreamReader reader = new StreamReader(@"Assets/Scripts/HighScore.txt"))
		{
			while (!reader.EndOfStream)
			{
				string l = reader.ReadLine();

				if (l != null && l.Trim() != "")
				{
					int.TryParse(l, out highScore);
				}
			}
		}

	}

	// Update is called once per frame
	void Update()
	{
		scoreText.text = "Current Score: " + playerScore + "\nHigh Score: " + highScore;

	}
}

