﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Pause : MonoBehaviour
{
    public static bool paused = false;
    private Text pausedText;

    private void Start()
    {
        pausedText = GetComponent<Text>();
    }

    public void pauseGame()
    {
        if (paused)
        {
            Time.timeScale = 1;
            paused = false;
            pausedText.enabled = false;
        }
        else
        {
            Time.timeScale = 0;
            paused = true;
            pausedText.enabled = true;
            pausedText.text = "PAUSED";
        }
    }
}
