﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RestartLevel : MonoBehaviour
{

    // Update is called once per frame
    void Update()
    {
        //If the player hits the R key, the program will restart 
        if (Input.GetKeyDown(KeyCode.R))
        {
            
            Scene scene = SceneManager.GetActiveScene();

            if (scene.name == "FirstLevel")
            {
                PlayerScore.playerScore = 0;
                GameOver.isPlayerDead = false;
                Time.timeScale = 1;

                SceneManager.LoadScene("FirstLevel");
            }

            else if(scene.name == "SecondLevel")
            {
                if (Win.ifWin)
                {
                    PlayerScore.playerScore = 0;
                    GameOver.isPlayerDead = false;
                    Time.timeScale = 1;

                    SceneManager.LoadScene("FirstLevel");
                }

                else
                {
                    PlayerScore.playerScore = NewScene.firstLevelScore;

                    GameOver.isPlayerDead = false;
                    Time.timeScale = 1;

                    SceneManager.LoadScene("SecondLevel");
                }
            }
        }
    }
}
