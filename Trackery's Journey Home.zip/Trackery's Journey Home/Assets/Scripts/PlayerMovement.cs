﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public CharacterMovement controller;
    public Animator aminmator;
    public static float characterMove = 0f;
    public float speed = 80;

    bool jump = false;
    bool leftB = false;
    public static string direction;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {   
        characterMove = Input.GetAxisRaw("Horizontal") * speed;

        aminmator.SetFloat("Speed", Mathf.Abs(characterMove));

        if(Input.GetAxisRaw("Horizontal") > 0)
        {
            direction = "right";

        }

        if (Input.GetAxisRaw("Horizontal") < 0)
        {
            direction = "left";
        }

        if (Input.GetButtonDown("Jump"))
        {
            jump = true;
    
        }

        if (Camera.main.WorldToViewportPoint(transform.position).y < 0)
        {
            GameOver.isPlayerDead = true;
        }

        if (Input.GetButton("Fire1"))
        {
            aminmator.SetFloat("Speed", Mathf.Abs(1));
        }

    }
    private void FixedUpdate()
    {

        //Move the character
        controller.Move(characterMove * Time.fixedDeltaTime, jump);
        jump = false;

   

    }
}
