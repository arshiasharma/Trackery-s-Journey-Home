﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CrossBow : MonoBehaviour
{
    public GameObject shot;
   
    public Transform shotSpawn;
    public float fireRate = 0.997f;
    private float nextFire;
    SpriteRenderer m_SpriteRenderer;


    private AudioSource audioS;

    // Start is called before the first frame update
    void Start()
    {
        m_SpriteRenderer = GetComponent<SpriteRenderer>();
        m_SpriteRenderer.enabled = false;
        audioS = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Pause.paused == false)
        {
            //normal bullet
            if (Input.GetButton("Fire1") && Time.time > nextFire)
            {
                StartCoroutine(Example());
                nextFire = Time.time + fireRate;
                audioS.Play();
                Instantiate(shot, shotSpawn.position, shotSpawn.rotation);

            }
        }
    }

    IEnumerator Example()
    {
        m_SpriteRenderer.enabled = true;
        yield return new WaitForSeconds(0.3f);
        m_SpriteRenderer.enabled = false;
    }
}
